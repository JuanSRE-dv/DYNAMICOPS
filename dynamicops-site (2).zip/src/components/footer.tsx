"use client";

import { Rocket, Github, Twitter, Linkedin } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/context/i18n";

export function Footer() {
    const { t } = useI18n();
  return (
    <footer className="bg-secondary">
      <div className="container mx-auto px-6 py-8">
        <div className="flex flex-col items-center text-center">
          <Link href="/" className="flex items-center space-x-2">
            <Rocket className="h-8 w-8 text-primary" />
            <span className="text-3xl font-bold font-headline text-foreground">
              DYNAMICOPS CONSULTING
            </span>
          </Link>
          <p className="max-w-md mx-auto mt-4 text-gray-400">
            {t('footer.tagline')}
          </p>
          <div className="flex justify-center mt-6 space-x-4">
            <Button variant="ghost" size="icon" asChild>
              <Link href="#" aria-label="Github">
                <Github className="h-5 w-5" />
              </Link>
            </Button>
            <Button variant="ghost" size="icon" asChild>
              <Link href="#" aria-label="Twitter">
                <Twitter className="h-5 w-5" />
              </Link>
            </Button>
            <Button variant="ghost" size="icon" asChild>
              <Link href="#" aria-label="LinkedIn">
                <Linkedin className="h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
        <hr className="my-8 border-gray-700" />
        <div className="text-center text-sm text-gray-500">
          <p>&copy; {new Date().getFullYear()} {t('footer.copyright')}</p>
        </div>
      </div>
    </footer>
  );
}