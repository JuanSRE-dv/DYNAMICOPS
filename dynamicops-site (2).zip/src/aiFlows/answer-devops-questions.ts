'use server';

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnswerDevOpsQuestionsInputSchema = z.object({
  question: z.string().describe('The DevOps question from the user.'),
});
export type AnswerDevOpsQuestionsInput = z.infer<typeof AnswerDevOpsQuestionsInputSchema>;

const AnswerDevOpsQuestionsOutputSchema = z.object({
  answer: z.string().describe('The answer to the DevOps question.'),
  serviceRecommendation: z
    .string()
    .describe('A service recommendation based on the question.'),
});
export type AnswerDevOpsQuestionsOutput = z.infer<typeof AnswerDevOpsQuestionsOutputSchema>;

export async function answerDevOpsQuestions(
  input: AnswerDevOpsQuestionsInput
): Promise<AnswerDevOpsQuestionsOutput> {
  return answerDevOpsQuestionsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'answerDevOpsQuestionsPrompt',
  input: {schema: AnswerDevOpsQuestionsInputSchema},
  output: {schema: AnswerDevOpsQuestionsOutputSchema},
  prompt: `You are Juan, an AI assistant for DYNAMICOPS CONSULTING, a DevOps consulting company.

  Answer the user's DevOps question and recommend a relevant DYNAMICOPS CONSULTING service.

  Question: {{{question}}}
  `,
});

const answerDevOpsQuestionsFlow = ai.defineFlow(
  {
    name: 'answerDevOpsQuestionsFlow',
    inputSchema: AnswerDevOpsQuestionsInputSchema,
    outputSchema: AnswerDevOpsQuestionsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);