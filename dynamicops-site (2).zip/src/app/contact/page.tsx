"use client";

import { ContactForm } from "@/components/contact-form";
import { Mail, Phone, MapPin } from "lucide-react";
import { useI18n } from "@/context/i18n";

export default function ContactPage() {
  const { t } = useI18n();
  return (
    <>
      <header className="py-20 md:py-32 bg-secondary/50">
        <div className="container mx-auto px-6 text-center">
          <h1 className="font-headline text-4xl md:text-6xl font-bold">{t('contact.title')}</h1>
          <p className="mt-4 text-lg md:text-xl text-foreground/80 max-w-3xl mx-auto">
            {t('contact.subtitle')}
          </p>
        </div>
      </header>

      <section className="py-20 md:py-28">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16">
            <div className="bg-secondary p-8 rounded-lg">
              <h2 className="font-headline text-3xl font-bold mb-6">{t('contact.form.title')}</h2>
              <ContactForm />
            </div>
            <div className="space-y-8">
              <div>
                <h3 className="font-headline text-2xl font-bold mb-4">{t('contact.info.title')}</h3>
                <p className="text-foreground/70 mb-6">
                  {t('contact.info.description')}
                </p>
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <Mail className="w-6 h-6 text-primary" />
                    <a href="mailto:contact@dynamicopsconsulting.com" className="text-foreground hover:text-primary transition-colors">
                      contact@dynamicopsconsulting.com
                    </a>
                  </div>
                   <div className="flex items-center gap-4">
                    <Phone className="w-6 h-6 text-primary" />
                    <a href="tel:+1234567890" className="text-foreground hover:text-primary transition-colors">
                      +1 (234) 567-890
                    </a>
                  </div>
                   <div className="flex items-center gap-4">
                    <MapPin className="w-6 h-6 text-primary" />
                    <span className="text-foreground">
                      123 Tech Avenue, Silicon Valley, CA
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}